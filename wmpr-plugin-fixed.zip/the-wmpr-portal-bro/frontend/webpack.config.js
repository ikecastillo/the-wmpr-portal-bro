const path = require('path');
const WrmPlugin = require('atlassian-webresource-webpack-plugin');
const webpack = require('webpack');

const xmlOutPath = path.resolve(
    '..', 'backend', 'src', 'main', 'resources', 'META-INF', 'plugin-descriptors', 'wr-defs.xml'
)

module.exports = (_, { mode }) => {
    const watch = mode !== 'production'
    const isProduction = mode === 'production'

    return {
        watch,
        mode: mode || 'development',
        resolve: {
            extensions: ['.tsx', '.ts', '.js', '.jsx']
        },
        module: {
            rules: [{
                test: /\.tsx?$/,
                exclude: /node_modules/,
                use: { 
                    loader: "babel-loader",
                    options: {
                        presets: [
                            ['@babel/preset-env', { modules: false }],
                            '@babel/preset-react',
                            '@babel/preset-typescript'
                        ]
                    }
                }
            }]
        },
        entry: {
            'wmprRequestsTable': './src/wmpr-requests-table.tsx',
            'wmprSettings': './src/wmpr-settings.tsx'
        },
        // Simplified optimization since we're using externals
        optimization: {
            usedExports: true,
            sideEffects: false
        },
        // Configure externals for Jira-provided dependencies
        externals: {
            // CRITICAL: React externals must match exactly what Jira provides
            'react': {
                root: 'React',
                commonjs: 'react',
                commonjs2: 'react',
                amd: 'react'
            },
            'react-dom': {
                root: 'ReactDOM', 
                commonjs: 'react-dom',
                commonjs2: 'react-dom',
                amd: 'react-dom'
            },
            // jQuery external
            'jquery': {
                root: 'jQuery',
                commonjs: 'jquery',
                commonjs2: 'jquery',
                amd: 'jquery'
            },
            '$': 'jQuery',
            // FIXED: Simplified AtlasKit external mappings that work with Jira's AtlasKit wrapper
            // These should be bundled since Jira's AtlasKit wrapper may not expose them properly
            // '@atlaskit/button': 'AtlasKitButton',
            // '@atlaskit/spinner': 'AtlasKitSpinner', 
            // '@atlaskit/lozenge': 'AtlasKitLozenge',
            // '@atlaskit/dynamic-table': 'AtlasKitDynamicTable'
            // REMOVED: AtlasKit externals - let webpack bundle them instead
            // This ensures components work regardless of Jira's AtlasKit wrapper availability
        },
        plugins: [
            // Add tracking identifier banner
            new webpack.BannerPlugin({
                banner: 'IKKKKKKE-WEBPACK-BUILD-001 - WMPR Bundle Loading Check',
                raw: false,
                entryOnly: true
            }),
            new WrmPlugin({
                watch,
                locationPrefix: '/frontend',
                pluginKey: 'com.example.wmpr.backend',
                xmlDescriptors: xmlOutPath,
                contextMap: {
                    'wmprRequestsTable': [
                        'servicedesk.portal.footer', 
                        'atl.general',
                        'atl.admin',  // For admin/project config pages
                        'jira.project.sidebar'  // For project-specific contexts
                    ],  // Load in multiple contexts including project config
                    'wmprSettings': [
                        'atl.admin',  // For admin/project config pages
                        'jira.project.sidebar',  // For project-specific contexts
                        'atl.general'  // General context for testing
                    ]  // Settings component for project configuration
                },
                // CRITICAL: Add proper dependencies for React components
                dependencies: {
                    'wmprRequestsTable': [
                        'com.atlassian.jira.plugins.jira-react-plugin:react',
                        'com.atlassian.auiplugin:ajs',
                        'jira.webresources:jira-global',
                        'jira.webresources:util'
                    ],
                    'wmprSettings': [
                        'com.atlassian.jira.plugins.jira-react-plugin:react',
                        'com.atlassian.auiplugin:ajs', 
                        'jira.webresources:jira-global',
                        'jira.webresources:util'
                    ]
                },
                // Jira provides these dependencies
                providedDependencies: {
                    'AJS': {
                        dependency: 'com.atlassian.auiplugin:ajs',
                        import: 'AJS'
                    },
                    'React': {
                        dependency: 'com.atlassian.jira.plugins.jira-react-plugin:react',
                        import: 'React'
                    },
                    'ReactDOM': {
                        dependency: 'com.atlassian.jira.plugins.jira-react-plugin:react',
                        import: 'ReactDOM'
                    },
                    'jQuery': {
                        dependency: 'jira.webresources:jira-global',
                        import: 'jQuery'
                    }
                }
            }),
        ],
        output: {
            filename: 'bundled.[name].js', // Hardcoded filename for consistent loading
            path: path.resolve("../backend/src/main/resources/frontend"),
            // FIXED: Simpler library exposure that should work more reliably
            library: {
                name: 'WMPR_[name]',
                type: 'window',
                export: 'default'
            },
            globalObject: 'window',
            // Ensure proper chunk loading
            chunkLoadingGlobal: 'webpackChunkWMPR',
            // Add clean option for consistent builds
            clean: true
        },
        // Performance budgets to catch large bundles
        performance: {
            maxAssetSize: 50000, // Much smaller since we're using externals
            maxEntrypointSize: 100000, 
            hints: 'warning'
        }
    };
};